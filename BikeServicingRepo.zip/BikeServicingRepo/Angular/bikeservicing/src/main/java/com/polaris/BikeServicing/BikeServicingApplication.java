package com.polaris.BikeServicing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikeServicingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BikeServicingApplication.class, args);
	}

}
