import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { BikeservicingComponent } from './bike-service/bikeservicing/bikeservicing.component';
import { ServicecategoryComponent } from './bike-service/servicecategory/servicecategory.component';
import { BookingComponent } from './bike-service/booking/booking.component';
import { AdminComponent } from './admin/admin/admin.component';



const routes: Routes = [
  {path:'home', component:WelcomeComponent},
  {path: 'servicing', component: BikeservicingComponent},
  {path: 'booking', component: BookingComponent},
  {path: 'scategory', component: ServicecategoryComponent},
  {path: 'admin', component: AdminComponent},
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
