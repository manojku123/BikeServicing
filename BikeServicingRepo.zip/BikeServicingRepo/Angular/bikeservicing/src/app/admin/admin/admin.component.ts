import { Component, OnInit } from '@angular/core';
import { BikeService } from 'src/app/service/bike.service';
import { CustomerRecordModel } from 'src/app/model/customer-record-model';
import { BookingModel } from 'src/app/model/booking-model';

@Component({
 
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  private title: string='Bike servicing and parts store';
  private truncateTableTitle: string = 'Delete record'
  private customerRecordTitle: string = 'Get customer record'
  truncateResponse: boolean;
  truncateMessage: string;
  customerRecord: BookingModel[];
  constructor(private httpClientService: BikeService) { }
  recordCond: boolean= false;
  truncateCond: boolean= false;
  trunMess: boolean = true;
  recordMess: boolean = true;
  ngOnInit() {
  }

  custRecord()
  {
    this.recordMess = ! this.recordMess;
    this.recordCond = !this.recordCond;
   this.httpClientService.getCustomerRecord().subscribe(
data => this.customerRecord = data as BookingModel[],
err => console.log(err),
() => {
  console.log('customer record loaded ')
}
   );
  }

  truncate()
  {
    this.trunMess = ! this.trunMess;
    this.truncateCond = !this.truncateCond;
    this.httpClientService.truncatCustomerRecord().subscribe(
     data => this.truncateResponse = data as boolean,
     err => console.log(err),
     () => {
     if(this.truncateResponse === true)
     {
      this.truncateMessage = 'customer record deleted succefully'
     }
    }
    );
  }
}
