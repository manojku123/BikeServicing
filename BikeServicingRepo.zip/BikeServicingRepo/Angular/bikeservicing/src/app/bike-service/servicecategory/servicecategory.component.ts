import { Component, OnInit } from '@angular/core';
import { BikeService } from 'src/app/service/bike.service';
import { ServiceCategoryModel } from 'src/app/model/service-category-model';
import { Router } from '@angular/router';
import { Time, getLocaleDateTimeFormat, formatDate } from '@angular/common';
import { WorkersModel } from 'src/app/model/workers-model';
import { BookingModel } from 'src/app/model/booking-model';
import { TimeSlot } from 'src/app/model/time-slot';
import { CustomerRecordModel } from 'src/app/model/customer-record-model';

@Component({
  
  templateUrl: './servicecategory.component.html',
  styleUrls: ['./servicecategory.component.css']
})
export class ServicecategoryComponent implements OnInit {

  private title: string='Bike servicing and parts store';
  serviceCategory: ServiceCategoryModel[];
  serviceTime: number;
  serviceCategoryName: string;
  today=new Date();
  bikeNo: string='br01 0810';
  mobileNo: number = 9620174302;
  currentTime: string;
  response: number;
  bookingConfirmmessage: string;
  customerRecord: CustomerRecordModel[];
  
  constructor(private httpClientService: BikeService, private router:Router)
   { 
     this.currentTime = formatDate(this.today,'dd:MM:yyyy hh:mm:ss','en-US');
    console.log(this.currentTime);
   }

  ngOnInit() {
    this.getServiceCategory();
    this.getCustRecord()
  }

  //getting service category*********************
  getServiceCategory()
  {
    this.httpClientService.getServiceCategory().subscribe(
      data => this.serviceCategory = data as  ServiceCategoryModel[],
      err => console.log(err),
      () => {
        console.log('service category loaded')   
      }
    );
  }

  //getting all customer records****************************
  getCustRecord(): void
  {
  
   this.httpClientService.getCustomerRecord().subscribe(
data => this.customerRecord = data as CustomerRecordModel[],
err => console.log(err),
() => {
  console.log('customer record loaded ')
}
   );
  }
  //method run after click on button***********************
  cond: boolean = false;
  calculateAvailableTimeSlot(category: string)
  {
 if(category != 'true')
 {

   for(let i=0; i < this.serviceCategory.length; i++)
   {
     if(category === this.serviceCategory[i].service)
     {
       this.serviceTime=this.serviceCategory[i].serviceTime;
       this.serviceCategoryName = this.serviceCategory[i].service;
       this.cond = true;
     }
   }
  }else{
        this.httpClientService.addCustomerRecord(new BookingModel(this.mobileNo,this.bikeNo,this.serviceCategoryName,this.serviceTime)).subscribe(
          data => this.response = data as number,
          err => console.log(err),
          () => {
            console.log('res: '+this.response)
            if(this.response == 1)
            {
             this.bookingConfirmmessage='Booking confimed, '+
             'please submit your bike as soon as possible. After servicing will call you to get back your bike. Thanks !!';
            }
            else if(this.response == 10){
            this.bookingConfirmmessage='this bike no or mobile no is already booked for servicing';
            }
            else{
              this.bookingConfirmmessage='Sorry !!, slot is not available';
            }
            this.cond=false;
            this.router.navigate(['/booking'], {fragment: this.bookingConfirmmessage})
          }
        );
  }
  }

  goBack()
{
this.router.navigate(['/servicing']);
}

}
