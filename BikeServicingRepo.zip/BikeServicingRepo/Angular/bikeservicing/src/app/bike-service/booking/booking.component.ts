import { Component, OnInit } from '@angular/core';
import { BikeService } from 'src/app/service/bike.service';
import { WorkersModel } from 'src/app/model/workers-model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({

  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
private title: string='Bike servicing and parts store';
message: string;
  constructor(private httpClientService: BikeService, private route: ActivatedRoute, 
    private router: Router ) { }

  ngOnInit() {
  this.message=this.route.snapshot.fragment;
  }
  goBack()
{
this.router.navigate(['/servicing']);
}
}
