import { Component, OnInit } from '@angular/core';
import { BikeService } from 'src/app/service/bike.service';
import { Shopmodel } from 'src/app/model/shopmodel';

@Component({
 
  templateUrl: './bikeservicing.component.html',
  styleUrls: ['./bikeservicing.component.css']
})
export class BikeservicingComponent implements OnInit {
private title: string='Bike servicing and parts store';
shopDetails: Shopmodel[] =[];
  constructor(
    private httpClientService: BikeService
  ) { }

  ngOnInit() {
    this.getAllShopDetails();
  }
  getAllShopDetails()
  {
    this.httpClientService.getAllShop().subscribe(
    (data) => {this.shopDetails = data as Shopmodel[]},
    err => console.log(err),
    () => {console.log('shop details loaded')  }
    );
  }

}
