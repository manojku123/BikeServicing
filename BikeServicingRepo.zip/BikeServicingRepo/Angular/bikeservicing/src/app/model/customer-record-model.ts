export class CustomerRecordModel {
    constructor(
        public  bikeNo: string,
        public  mob_no: string,
         public serviceCatName: string,
         public serviceTimeDuration: number
    ){}
}
