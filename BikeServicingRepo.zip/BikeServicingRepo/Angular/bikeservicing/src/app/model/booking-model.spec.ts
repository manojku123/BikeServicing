import { BookingModel } from './booking-model';

import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, async } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('BookingModel', () => {beforeEach(async(() => {
  TestBed.configureTestingModule({
    imports: [
      RouterTestingModule,HttpClientTestingModule
    ],
    declarations: [
      BookingModel
    ],
  }).compileComponents();
}));
  // it('should create an instance', () => {
  //   expect(new BookingModel(45454,'bikeno','service anme',10)).toBeTruthy();
  // });
});
