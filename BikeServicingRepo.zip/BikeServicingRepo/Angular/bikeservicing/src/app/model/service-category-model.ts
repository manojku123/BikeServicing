import { Time } from '@angular/common';

export class ServiceCategoryModel {
    constructor(
        public id: number,
        public service:string,
        public serviceTime: number
    ){}
}
