import { ServiceCategoryModel } from './service-category-model';

describe('ServiceCategoryModel', () => {
  it('should create an instance', () => {
    expect(new ServiceCategoryModel(1,'service',10)).toBeTruthy();
  });
});
