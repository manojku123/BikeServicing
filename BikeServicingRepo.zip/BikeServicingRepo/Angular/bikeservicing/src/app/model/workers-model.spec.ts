import { WorkersModel } from './workers-model';

describe('WorkersModel', () => {
  it('should create an instance', () => {
    expect(new WorkersModel(1,'name','10')).toBeTruthy();
  });
});
