import { TimeSlot } from './time-slot';

describe('TimeSlot', () => {
  it('should create an instance', () => {
    expect(new TimeSlot('time slot')).toBeTruthy();
  });
});
