import { Shopmodel } from './shopmodel';

describe('Shopmodel', () => {
  it('should create an instance', () => {
    expect(new Shopmodel(1, 'shop')).toBeTruthy();
  });
});
