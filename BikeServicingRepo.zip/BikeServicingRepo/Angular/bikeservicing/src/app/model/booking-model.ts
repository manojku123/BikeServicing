export class BookingModel {
    constructor(
        public mobileNo: number,
        public bikeNo: string,
        public serviceName: string,
        public serviceTime: number
       
    ){}
}
