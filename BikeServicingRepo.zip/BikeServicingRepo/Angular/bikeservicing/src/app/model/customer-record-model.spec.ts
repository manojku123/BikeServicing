import { CustomerRecordModel } from './customer-record-model';

describe('CustomerRecordModel', () => {
  it('should create an instance', () => {
    expect(new CustomerRecordModel('bike no','mobile_no','service anme',10)).toBeTruthy();
  });
});
