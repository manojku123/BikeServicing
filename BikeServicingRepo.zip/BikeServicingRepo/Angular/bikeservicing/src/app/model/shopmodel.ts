export class Shopmodel {
    constructor(
        public id: number,
        public shop: string
    ){}
}
