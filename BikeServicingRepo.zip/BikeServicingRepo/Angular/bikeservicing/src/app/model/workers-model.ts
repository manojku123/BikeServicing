import { Time } from '@angular/common';

export class WorkersModel {
    constructor(
    public wId: number,
    public name: string,
    public workingHours: string
    ){}
}
