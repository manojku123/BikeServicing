export class TimeSlot {
    constructor(
        public timeslot: string
    ){}
}
