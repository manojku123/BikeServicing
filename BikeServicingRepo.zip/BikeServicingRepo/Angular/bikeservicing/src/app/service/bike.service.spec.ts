import { TestBed } from '@angular/core/testing';

import { BikeService } from './bike.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('BikeService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule
    ],
  }));

  it('should be created', () => {
    const service: BikeService = TestBed.get(BikeService);
    expect(service).toBeTruthy();
  });
});
