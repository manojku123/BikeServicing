import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BookingModel } from '../model/booking-model';
const httpOptions={
  headers: new HttpHeaders({'content-type': 'application/json'})
};
@Injectable({
  providedIn: 'root'
})
export class BikeService {

  constructor(
    private http: HttpClient
  ) {  }

  getAllShop()
  {
    return this.http.get('/server/bikeservice/getbikeshop');
  }
  getServiceCategory()
  {
    return this.http.get('/server/bikeservice/getscategory');
  }
  getWorkers()
  {
    return this.http.get('/server/bikeservice/getWorker');
  }
  addCustomerRecord(custRecord)
  {
   let body = JSON.stringify(custRecord);
    return this.http.post('/server/bikeservice/addcustomerrecord', body, httpOptions);
  }
  truncatCustomerRecord()
  {
    return this.http.get('/server/bikeservice/truncatecusrec');
  }
  getCustomerRecord()
  {
    return this,this.http.get('/server/bikeservice/getcustomerrecord')
  }
}
