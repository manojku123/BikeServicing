package com.polaris.BikeServicing.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.polaris.BikeServicing.model.CustomerRecord;

@Repository
public interface CustomerRecRepo extends CrudRepository<CustomerRecord,Long>{

}
