package com.polaris.BikeServicing.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.polaris.BikeServicing.model.Workers;

@Repository
public interface WorkersRepo extends CrudRepository<Workers, Integer>{

}
