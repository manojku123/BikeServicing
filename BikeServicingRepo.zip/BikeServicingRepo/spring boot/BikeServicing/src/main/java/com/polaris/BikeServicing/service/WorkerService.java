package com.polaris.BikeServicing.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.polaris.BikeServicing.model.Workers;
import com.polaris.BikeServicing.repository.WorkersRepo;

@Service
public class WorkerService {

	@Autowired
	private WorkersRepo worker;

	public List<Workers> getAllWorkers() {
		return (List<Workers>) worker.findAll();
	}
}
