package com.polaris.BikeServicing.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.polaris.BikeServicing.model.BikeShops;
import com.polaris.BikeServicing.model.CustomerRecord;
import com.polaris.BikeServicing.model.ServiceCategory;
import com.polaris.BikeServicing.model.Workers;
import com.polaris.BikeServicing.repository.CustomerRecRepo;
import com.polaris.BikeServicing.service.BikeShopService;
import com.polaris.BikeServicing.service.CustomerRecordService;
import com.polaris.BikeServicing.service.ServiceCategoryService;
import com.polaris.BikeServicing.service.WorkerService;

@RestController
@RequestMapping(path="/bikeservice")
public class BikeServiceController {

	@Autowired
	private BikeShopService bsSrvice;
	@Autowired
	private ServiceCategoryService scSrvice;
	@Autowired
	private WorkerService wSrvice;
	@Autowired
	private CustomerRecordService recordSrvice;
	@Autowired
	private CustomerRecRepo cusRecRepo;
	
	
	
	@GetMapping("/getbikeshop")
	public List<BikeShops> getBikeShop()
	{
		return bsSrvice.getAllBikeShops();
	}
	@GetMapping("/getscategory")
	public List<ServiceCategory> getServiceCategory()
	{
		return scSrvice.getAllServiceCategory();
	}
	@GetMapping("/getWorker")
	public List<Workers> getWorker()
	{
		return wSrvice.getAllWorkers();
	}
	@PostMapping("/addcustomerrecord")
	public int addCustRecords(@RequestBody CustomerRecord record) {
		
		return recordSrvice.addRecords(record);
	}
	@GetMapping("/truncatecusrec")
	public boolean truncateCustomerRecord()
	{
	cusRecRepo.deleteAll();
		for(int i=0;i< recordSrvice.totalWorkingHoursArray.size();i++)
		{
			recordSrvice.totalWorkingHoursArray.set(i, 1);
		}
		int no =10;
		for(int j=0;j<recordSrvice.hoursArray.length;j++)
		{
			recordSrvice.hoursArray[j]=no++;
		}
		
		return true;
	}
	@GetMapping("/getcustomerrecord")
	public List<CustomerRecord> getCustomerRecord()
	{
		return (List<CustomerRecord>) cusRecRepo.findAll();
		
	}
}

