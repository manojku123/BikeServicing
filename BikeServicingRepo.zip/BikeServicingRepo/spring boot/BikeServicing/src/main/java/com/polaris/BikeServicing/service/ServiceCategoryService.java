package com.polaris.BikeServicing.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.polaris.BikeServicing.model.ServiceCategory;
import com.polaris.BikeServicing.repository.ServiceCategoryRepo;

@Service
public class ServiceCategoryService {
	
	@Autowired
	private ServiceCategoryRepo scRepository;

	public List<ServiceCategory> getAllServiceCategory() {
		return (List<ServiceCategory>) scRepository.findAll();
	}

}
