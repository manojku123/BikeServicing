package com.polaris.BikeServicing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BikeShops")
public class BikeShops {
	@Id
	@Column(name="id")
	private Integer id;
	@Column(name="shop")
	private String shop;
	
	public BikeShops() {
		
	}
	public BikeShops(Integer id, String shop) {
		super();
		this.id = id;
		this.shop = shop;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}
	
	

}
