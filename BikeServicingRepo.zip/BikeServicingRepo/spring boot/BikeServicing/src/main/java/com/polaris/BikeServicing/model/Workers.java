package com.polaris.BikeServicing.model;

import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="workers")
public class Workers {

	@Id
	@Column(name="wId")
	private Integer wId;
	@Column(name="name")
	private String name;
	@Column(name="workingHours")
	private Integer workingHours;
	
	public Workers()
	{
		
	}
	public Workers(Integer wId, String name, Integer workingHours) {
		super();
		this.wId = wId;
		this.name = name;
		this.workingHours = workingHours;
	}
	public Integer getwId() {
		return wId;
	}
	public void setwId(Integer wId) {
		this.wId = wId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getWorkingHours() {
		return workingHours;
	}
	public void setWorkingHours(Integer workingHours) {
		this.workingHours = workingHours;
	}
	@Override
	public String toString() {
		return "Workers [wId=" + wId + ", name=" + name + ", workingHours=" + workingHours + "]";
	}
    

}

