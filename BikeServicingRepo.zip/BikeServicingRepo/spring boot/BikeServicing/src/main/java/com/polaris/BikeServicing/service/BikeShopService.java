package com.polaris.BikeServicing.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.polaris.BikeServicing.model.BikeShops;
import com.polaris.BikeServicing.repository.BikeShopRepo;

@Service
public class BikeShopService {

	@Autowired
	private BikeShopRepo bsRepository;

	public List<BikeShops> getAllBikeShops() {
		return  (List<BikeShops>) bsRepository.findAll();
	}
}
