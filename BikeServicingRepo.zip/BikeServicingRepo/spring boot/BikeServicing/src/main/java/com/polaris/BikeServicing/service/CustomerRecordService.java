package com.polaris.BikeServicing.service;
import java.text.SimpleDateFormat;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.polaris.BikeServicing.model.CustomerRecord;
import com.polaris.BikeServicing.model.Workers;
import com.polaris.BikeServicing.repository.CustomerRecRepo;

import com.polaris.BikeServicing.repository.WorkersRepo;

@Service
public class CustomerRecordService {

	@Autowired
	private CustomerRecRepo recordRepo;
	@Autowired
	private WorkersRepo workerRepo;
	
	private CustomerRecord copyRecord;
	int totalHours=0;
	int availableSlot;
	int firstCall=1;
	public List<Integer> totalWorkingHoursArray = new ArrayList();  
	private List<Workers> workerList = new ArrayList();
	private int noOfWorkers;

	    SimpleDateFormat formatter;
	    Date date;
	    String currTime;
	    String[] splitTime;
	    int hour;
	    public int[] hoursArray = {10,11,12,13,14,15,16,17,18,19}; 

	public int addRecords(CustomerRecord record) {
		//validation for duplicate bike number*****************************************
		List<CustomerRecord> existRecord = (List<CustomerRecord>) recordRepo.findAll();
		for(CustomerRecord rec : existRecord)
		{
			if(rec.getBikeNo().equals(record.getBikeNo()) || rec.getMobileNo().equals(record.getMobileNo()))
			{
	
				return 10;
			}
		}
		//to get current time********************************
		formatter = new SimpleDateFormat("HH:mm:ss");  
		date = new Date();
		currTime = formatter.format(date);  
		splitTime = currTime.split(":");
		hour =Integer.parseInt(splitTime[0]);
		//to get availability of slot********************************
		copyRecord = record;
		
		availableSlot = calculateAvailableSlot();
		if(availableSlot ==1) {
		recordRepo.save(record);
		}
		return availableSlot;
		
	}
// calculate available time slot*****************
	private int calculateAvailableSlot() {
		int serTimeDuration = copyRecord.getServiceTime();	
		
		if(firstCall==1)
		{
			firstCall++;
			workerRepo.findAll().forEach(workerList :: add);
			noOfWorkers = workerList.size();
			for(Workers w : workerList)
			{
				totalHours += w.getWorkingHours();
			}
		for(int i=0; i<totalHours; i++)
		{
			totalWorkingHoursArray.add(i, 1);
		}
		
		}
		//deleting time of worker based on current time*************
		if(hour > 9)
		{
		int count=0;
			for(int k=0; k<hoursArray.length;k++)
			{
				
				if( hour == hoursArray[k])
				{
					for(int t=0;t<=k;t++)
					{
						if(hoursArray[t]!=0)
						{
							count+=noOfWorkers;
						}
					}
					for(int l=0; l <= k;l++) {
					hoursArray[l]=0;
					}
					break;
				}
				
			}
			
			for(int i=0;i<count;i++)
			{
				for(int j=0;j<totalWorkingHoursArray.size();j++)
				{
					if(totalWorkingHoursArray.get(j)==1)
					{
						totalWorkingHoursArray.set(j, 0);
						break;
					}
				}
			}
		}
		//checking availability of slot and returning value based on available slot***
		int i;
		for(i=0; i<totalWorkingHoursArray.size();i++)
		{
			if(totalWorkingHoursArray.get(i) == 1)
			{
				int count = 0;
				for(int k=0;k<totalWorkingHoursArray.size();k++) {
					count += totalWorkingHoursArray.get(k);
				}
				if(count>=serTimeDuration)
				{
					int l=i;
				for(int j=0;j<serTimeDuration;j++)
				{
					
					totalWorkingHoursArray.set(l, 0);
					l++;
				}
			
				return 1;
				}else {
					return 0;
				}
				
			}
			
		}
		return 2;
		
	}
	
}
