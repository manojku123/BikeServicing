package com.polaris.BikeServicing.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.polaris.BikeServicing.model.BikeShops;

@Repository
public interface BikeShopRepo extends CrudRepository<BikeShops,Integer>{

}
