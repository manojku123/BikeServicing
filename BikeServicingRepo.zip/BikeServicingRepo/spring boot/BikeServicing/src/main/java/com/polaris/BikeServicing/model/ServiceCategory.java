package com.polaris.BikeServicing.model;

import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="ServiceCategory")
public class ServiceCategory {

	@Id
	@Column(name="id")
	private Integer id;
	@Column(name="service")
	private String service;
	@Column(name="serviceTime")
	private Integer serviceTime;
	public ServiceCategory()
	{
		
	}
	public ServiceCategory(Integer id, String service, Integer serviceTime) {
		super();
		this.id = id;
		this.service = service;
		this.serviceTime = serviceTime;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public Integer getServiceTime() {
		return serviceTime;
	}
	public void setServiceTime(Integer serviceTime) {
		this.serviceTime = serviceTime;
	}
	
	
}
