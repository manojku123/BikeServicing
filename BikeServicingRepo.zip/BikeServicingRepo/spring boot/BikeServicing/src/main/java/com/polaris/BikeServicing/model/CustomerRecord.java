package com.polaris.BikeServicing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customerrecord")
public class CustomerRecord {

	@Id
	@Column(name="mobileno")
	private Long mobileNo;
	@Column(name="bikeno")
	private String bikeNo;
	@Column(name="servicename")
	private String serviceName;
	@Column(name="servicetime")
	private int serviceTime;
	
	public CustomerRecord()
	{
		
	}
	public CustomerRecord(String bikeNo, Long mobileNo, String serviceName, int serviceTime) {
		super();
		this.bikeNo = bikeNo;
		this.mobileNo = mobileNo;
		this.serviceName = serviceName;
		this.serviceTime = serviceTime;
	}
	public String getBikeNo() {
		return bikeNo;
	}
	public void setBikeNo(String bikeNo) {
		this.bikeNo = bikeNo;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public int getServiceTime() {
		return serviceTime;
	}
	public void setServiceTime(int serviceTime) {
		this.serviceTime = serviceTime;
	}
	
}
