package com.polaris.BikeServicing.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.polaris.BikeServicing.model.ServiceCategory;

@Repository
public interface ServiceCategoryRepo extends CrudRepository<ServiceCategory, Integer>{

}
